#pragma once
#define  TFT_GRAY       0x7BEF
#define  TFT_LIGHT_GRAY 0xC618

void presentation();

void presentation(){
  
}
