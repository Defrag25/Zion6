# 4DOFManipulator
A forward- and inverse kinematics library for Arduino, solving for 4DOF (x, y, z, phi) Robotic Arms, using algebraic methods.
