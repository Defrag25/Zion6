#include "deplacements.c"


task main()
{


}
