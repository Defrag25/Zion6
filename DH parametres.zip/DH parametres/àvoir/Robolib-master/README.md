# PE_Coupe_ECL

GitHub officiel du projet ERACL pour la Coupe de France de Robotique dans le cadre des PE de l'Ecole Centrale de Lyon.

