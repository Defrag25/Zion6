#include "config.c"
#include "position.c"
#include "movement.c"

task main()
{
  initConfig(ROCCO);
  initPosition(false);
}
