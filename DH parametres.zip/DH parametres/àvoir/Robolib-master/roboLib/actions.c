#include "config.c"
#include "movement.c"

// La task suivante verifie toutes les 20 ms si le bouton d'arret d'urgence a ete actionne.
