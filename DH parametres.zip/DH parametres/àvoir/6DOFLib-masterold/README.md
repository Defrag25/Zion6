# 6DOFLib
A work in progress of a 6DOF kinematics library for Arduino
